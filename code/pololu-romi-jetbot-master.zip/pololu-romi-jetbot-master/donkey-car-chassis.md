The Donkey Car HSP 94186 chassis doen't seem a particularly popular model.

If you look on Banggood you'll find far more popular models: <https://www.banggood.com/Wholesale-RC-Car-c-1753-0-1-4-36-0_page1.html>

They appear to have sold no HSP 94186 chassis.

HobbyKing have various popular models. Here are the top 10, in the 1/10 to 1/16 scale range, sorted by number of reviews:

* 158 <https://hobbyking.com/en_us/turnigy-trooper-sct-4x4-1-10-brushless-short-course-truck-arr.html>
* 153 <https://hobbyking.com/en_us/wild-willy-2-2000-wr-02.html>
* 111 <https://hobbyking.com/en_us/tt-02-porsche-911-carrerarsr-w-105bk-torque-tuned.html>
* 111 <https://hobbyking.com/en_us/tamiya-1-10-scale-ford-bronco-1973-cr01-series-kit.html>
* 111 <https://hobbyking.com/en_us/tamiya-1-10-scale-ford-bronco-1973-cc01-series-kit-58469.html>
* 55 <https://hobbyking.com/en_us/1-10-hobbykingr-mission-d-4wd-gtr-drift-car-arr.html>
* 38 <https://hobbyking.com/en_us/turnigy-sct-2wd-1-10-brushless-short-course-truck-kit-upgraded-version.html>
* 35 <https://hobbyking.com/en_us/tamiya-manta-ray-1-10th-scale-off-road-4wd-electric-buggy-kit-limited-edition.html>
* 24 <https://hobbyking.com/en_us/tamiya-ta07-pro-1-10-scale-touring-car-kit.html>
* 24 <https://hobbyking.com/en_us/tamiya-1-10-scale-skyline-gt-r-z-tune-r34-tt02d-series-kit-58605.html>

Number 1 is the Turingy Trooper - which is a suggested Donkey Car chassis - at 1/10 it's quite big though.

Tamiya produce a huge range of chassis - unfortunately their website is terrible. A Tamiya chassis without unneeded body looks like a nice option.

Remember all these cars are probably built for speed, and many are built for all-terrain.

Whereas a gear ratio of 34:1 or 75:1 like the the Pololu Wild Thumper with high torque might be more appropriate and giving up some all-terrain performance might make for greater stability, less bounce, in flat indoor environments.

It'd be interesting to know what experience ETH has with chassis - <https://www.ethz.ch/en/news-and-events/eth-news/news/2018/01/lab-for-self-driving-vehicles.html>

It'd also be nice to know what chassis DeepRacer uses - it does seem to be monster truck chassis, so maybe I'm wrong in thinking something more car like would be better:

* <https://aws.amazon.com/deepracer/faqs/>
* <https://docs.aws.amazon.com/deepracer/latest/developerguide/deepracer-model-car-configuration.html>
