---
name: GUI compact engine page missing
about: jtop is not using a specific compact information page for this board
title: GUI compact engine page missing []
labels: GUI,missing
assignees: ''

---

Please add a new jtop engine compact page for
<!-- Complete all fields
  You can find this data on:
   * jetson_release -v
   * jtop (page INFO)
-->
### Board

- Model:
- 699-level Part Number:
- P-Number:
- Module:
- SoC:
- CUDA Arch BIN:
- Codename:
- L4T:
- Jetpack:

<!-- Use jtop -v -->
### jetson-stats

- Version:

<!-- Please attach a screnshoot page from jtop Engine page -->
### Screenshot engine page

Screnshoot page from jtop engine page attacched