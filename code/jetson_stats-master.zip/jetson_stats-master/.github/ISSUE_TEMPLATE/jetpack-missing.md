---
name: Jetpack missing
about: jetson-stats miss a JetPack
title: Jetpack missing [L4T e.g. 5.2.1]
labels: Jetpack,missing
assignees: ''

---

Please update jetson-stats with new jetpack
<!-- Complete all fields -->
### Linux for Tegra

- L4T: 

### jetson-stats
<!-- Use jtop -v -->
- Version: 
