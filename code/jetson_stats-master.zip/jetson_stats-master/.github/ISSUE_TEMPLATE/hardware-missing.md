---
name: Hardware Missing
about: jetson-stats does not recognize this hardware
title: Hardware Missing []
labels: Hardware,missing
assignees: ''

---

Please update jetson-stats with this board
<!-- Complete all fields
  You can find this data on:
   * jetson_release -v
   * jtop (page INFO)
-->
### Board

- Model:
- 699-level Part Number:
- P-Number:
- Module:
- SoC:
- CUDA Arch BIN:
- Codename:
- L4T:
- Jetpack:

<!-- Use jtop -v -->
### jetson-stats

- Version:

<!-- Please attach the output from: jtop --error-log -->
### RAW Data

File from `jtop --error-log` attached
