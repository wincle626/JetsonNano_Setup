💖 Sponsor 
==========

Please consider sponsoring jetson-stats development, especially if your company benefits from this library.

Your contribution will go towards adding new features to jetson-stats and making sure all functionality continues to meet our high quality standards.

.. important::

   `Get in contact <mailto:raffaello@rnext.it>`_ for additional
   details on sponsorship and perks before making a contribution
   through `GitHub Sponsors <https://github.com/sponsors/rbonghi>`_ if you have questions.
