🧰 Other tools
================

When you install jetson-stats there are also other tools included

.. toctree::

    jetson_config
    jetson_release
    jetson_swap
    environment_variables