Environment variables
=====================

This script generate the easy environment variables to know which is your
Hardware version of the Jetson and which Jetpack you have already installed.

.. image:: /images/jetson_env.png
   :align: center