📖 API Reference
=================

.. autoclass:: jtop.jtop
   :members:
   :show-inheritance:

